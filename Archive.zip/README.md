Michi Tanaka
mt50737@pausd.us

NIFTY: Automatically Solving SAT/TOEFL Synonym Questions with Computational Linguistics

## How to run the code

1. Open and extract the zip file
2. Open the terminal and navigate to the directory where the files are located
3. Run the following command to install the required packages:
   `python3 synonyms.py`

## Output

The program will display the overall percentage of problems it was able to solve correctly.

** Note: It may take several seconds before anything is displayed on the terminal. **
